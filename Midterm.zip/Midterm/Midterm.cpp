#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;

const int MAX_SIZE = 10; // Maximum stack size

// Define the Box structure
struct Box {
    int id;
    string itemName;
    float weight;
    string destination;
};

// Stack class
class Stack {
private:
    Box stack[MAX_SIZE];
    int top;

public:
    // Constructor
    Stack() {
        top = -1;
    }

    // Check if the stack is full
    bool isFull() {
        return top == MAX_SIZE - 1;
    }

    // Check if the stack is empty
    bool isEmpty() {
        return top == -1;
    }

    // Push a box onto the stack
    void push(Box box) {
        if (isFull()) {
            cout << "Error: Stack is full. Cannot add more boxes.\n";
        }
        else {
            stack[++top] = box;
            cout << "Box added to stack!\n";
        }
    }

    // Pop the top box from the stack
    void pop() {
        if (isEmpty()) {
            cout << "Error: Stack is empty. No boxes to dispatch.\n";
        }
        else {
            Box dispatched = stack[top--];
            cout << "Top box dispatched:\n";
            cout << "ID: " << dispatched.id << ", Item: " << dispatched.itemName << ", Destination: " << dispatched.destination << "\n";
        }
    }

    // Peek the top box
    Box peek() {
        if (isEmpty()) {
            throw runtime_error("Stack is empty");
        }
        return stack[top];
    }

    // View all boxes in the stack
    void displayStack() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
        }
        else {
            cout << "========= STACKED BOXES (Top to Bottom) =========\n";
            cout << "Box ID   Item         Weight(lbs.)   Destination\n";
            cout << "-----------------------------------------------\n";
            for (int i = top; i >= 0; i--) {
                cout << stack[i].id << "   " << stack[i].itemName << "   " << stack[i].weight << "   " << stack[i].destination << "\n";
            }
        }
    }

    // View inventory summary
    void inventorySummary() {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
        }
        else {
            int totalBoxes = top + 1;
            float totalWeight = 0;
            for (int i = 0; i <= top; i++) {
                totalWeight += stack[i].weight;
            }
            Box topBox = peek();
            cout << "========== INVENTORY SUMMARY ==========\n";
            cout << "Total Boxes in Stack: " << totalBoxes << "\n";
            cout << "Total Weight: " << totalWeight << " lbs.\n";
            cout << "Top Box: ID " << topBox.id << " - " << topBox.itemName << "\n";
            cout << "=======================================\n";
        }
    }

    // Save inventory to a file
    void saveToFile() {
        ofstream outFile("inventory.txt");
        if (outFile.is_open()) {
            for (int i = top; i >= 0; i--) {
                outFile << stack[i].id << "," << stack[i].itemName << "," << stack[i].weight << "," << stack[i].destination << "\n";
            }
            outFile.close();
            cout << "Inventory saved to inventory.txt. Have a productive day!\n";
        }
        else {
            cout << "Error saving to file.\n";
        }
    }
};

// Function to handle user input for adding a box
Box getBoxDetails() {
    Box newBox;
    cout << "Enter Box ID: ";
    cin >> newBox.id;
    cin.ignore(); // To ignore the newline character left by previous input
    cout << "Enter Item Name: ";
    getline(cin, newBox.itemName);
    cout << "Enter Weight (lbs.): ";
    cin >> newBox.weight;
    cin.ignore();
    cout << "Enter Destination: ";
    getline(cin, newBox.destination);
    return newBox;
}

int main() {
    Stack warehouseStack;
    int choice;

    cout << "****** Welcome to Warehouse Inventory Stack Tracker ******\n";

    do {
        cout << "Please choose one of the following operations:\n";
        cout << "1. Add Box to Stack\n";
        cout << "2. View Current Stack\n";
        cout << "3. Remove Top Box (Dispatch)\n";
        cout << "4. View Inventory Summary\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();  // Ignore newline character after input

        switch (choice) {
        case 1: {
            Box newBox = getBoxDetails();
            warehouseStack.push(newBox);
            break;
        }
        case 2:
            warehouseStack.displayStack();
            break;
        case 3:
            warehouseStack.pop();
            break;
        case 4:
            warehouseStack.inventorySummary();
            break;
        case 5:
            warehouseStack.saveToFile();
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 5);

    return 0;
}
