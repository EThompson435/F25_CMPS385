#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

struct Song {
    int id;
    string title;
    string artist;
    float duration;
    Song* prev;
    Song* next;
};

Song* head = nullptr;
Song* tail = nullptr;
Song* current = nullptr;

// Function declarations
void loadPlaylist();
void savePlaylist();
void addSong();
void displayPlaylist();
void playNext();
void playPrevious();
void removeSong();

int main() {
    loadPlaylist();

    int choice;
    do {
        cout << "\n****** Welcome to Music Playlist Manager ******\n";
        cout << "1. Add Song to Playlist\n";
        cout << "2. Display Playlist\n";
        cout << "3. Play Next Song\n";
        cout << "4. Play Previous Song\n";
        cout << "5. Remove Song\n";
        cout << "6. Save and Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); // clear newline

        switch (choice) {
        case 1: addSong(); break;
        case 2: displayPlaylist(); break;
        case 3: playNext(); break;
        case 4: playPrevious(); break;
        case 5: removeSong(); break;
        case 6:
            savePlaylist();
            cout << "Playlist saved. See you next jam!" << endl;
            break;
        default: cout << "Invalid option. Try again.\n";
        }
    } while (choice != 6);

    return 0;
}

// Load playlist from file
void loadPlaylist() {
    ifstream infile("playlist.txt");
    if (!infile) return;

    string line;
    while (getline(infile, line)) {
        Song* newSong = new Song;
        size_t pos1 = line.find(',');
        size_t pos2 = line.find(',', pos1 + 1);
        size_t pos3 = line.find(',', pos2 + 1);

        newSong->id = stoi(line.substr(0, pos1));
        newSong->title = line.substr(pos1 + 1, pos2 - pos1 - 1);
        newSong->artist = line.substr(pos2 + 1, pos3 - pos2 - 1);
        newSong->duration = stof(line.substr(pos3 + 1));

        newSong->prev = tail;
        newSong->next = nullptr;

        if (!head) head = newSong;
        if (tail) tail->next = newSong;
        tail = newSong;

        if (!current) current = head;
    }

    infile.close();
}

// Save playlist to file
void savePlaylist() {
    ofstream outfile("playlist.txt");
    Song* temp = head;
    while (temp) {
        outfile << temp->id << "," << temp->title << "," << temp->artist << "," << temp->duration << "\n";
        temp = temp->next;
    }
    outfile.close();
}

// Add song to playlist
void addSong() {
    Song* newSong = new Song;
    cout << "Enter Song ID: ";
    cin >> newSong->id;
    cin.ignore();
    cout << "Enter Title: ";
    getline(cin, newSong->title);
    cout << "Enter Artist: ";
    getline(cin, newSong->artist);
    cout << "Enter Duration (in minutes): ";
    cin >> newSong->duration;
    cin.ignore();

    newSong->prev = tail;
    newSong->next = nullptr;

    if (!head) head = newSong;
    if (tail) tail->next = newSong;
    tail = newSong;

    if (!current) current = head;

    cout << "Song added to playlist!" << endl;
}

// Display playlist
void displayPlaylist() {
    if (!head) {
        cout << "Playlist is empty." << endl;
        return;
    }

    cout << "========== CURRENT PLAYLIST ==========\n";
    cout << left << setw(5) << "ID"
        << setw(25) << "Title"
        << setw(20) << "Artist"
        << "Duration\n";
    cout << "----------------------------------------------------\n";

    Song* temp = head;
    while (temp) {
        cout << left << setw(5) << temp->id
            << setw(25) << temp->title
            << setw(20) << temp->artist
            << temp->duration << endl;
        temp = temp->next;
    }
}

// Play next song
void playNext() {
    if (!current) {
        cout << "Playlist is empty." << endl;
        return;
    }

    if (current->next) {
        current = current->next;
        cout << "Now playing: " << current->title << " by " << current->artist
            << " (" << current->duration << " min)" << endl;
    }
    else {
        cout << "You are at the last song." << endl;
    }
}

// Play previous song
void playPrevious() {
    if (!current) {
        cout << "Playlist is empty." << endl;
        return;
    }

    if (current->prev) {
        current = current->prev;
        cout << "Now playing: " << current->title << " by " << current->artist
            << " (" << current->duration << " min)" << endl;
    }
    else {
        cout << "You are at the first song." << endl;
    }
}

// Remove a song
void removeSong() {
    if (!head) {
        cout << "Playlist is empty." << endl;
        return;
    }

    int removeID;
    cout << "Enter Song ID to remove: ";
    cin >> removeID;
    cin.ignore();

    Song* temp = head;
    while (temp && temp->id != removeID) {
        temp = temp->next;
    }

    if (!temp) {
        cout << "Song not found." << endl;
        return;
    }

    if (temp->prev) temp->prev->next = temp->next;
    else head = temp->next;

    if (temp->next) temp->next->prev = temp->prev;
    else tail = temp->prev;

    if (current == temp) {
        if (temp->next) current = temp->next;
        else current = temp->prev;
    }

    cout << "Song '" << temp->title << "' removed from playlist." << endl;
    delete temp;
}
