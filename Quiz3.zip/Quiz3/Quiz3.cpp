#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

// Abstract Base Class
class Item {
private:
    string name;
    double price;

protected:
    Item(const string& n, double p) : name(n), price(p) {}
    double getBasePrice() const { return price; }

public:
    virtual void display() const = 0;
    virtual double getPrice() const = 0;
    virtual void receiptEntry() const = 0;
    string getName() const { return name; }
    virtual ~Item() {}
};

// Derived Class: FoodItem
class FoodItem : public Item {
    string expirationDate;

public:
    FoodItem(const string& n, double p, const string& exp)
        : Item(n, p), expirationDate(exp) {
    }

    void display() const override {
        cout << "Name: " << getName()
            << " | Price: $" << fixed << setprecision(2) << getPrice()
            << " | Exp: " << expirationDate << endl;
    }

    double getPrice() const override {
        return getBasePrice();
    }

    void receiptEntry() const override {
        cout << getName() << " - $" << fixed << setprecision(2) << getPrice() << endl;
    }
};

// Derived Class: ElectronicItem
class ElectronicItem : public Item {
    int warrantyMonths;

public:
    ElectronicItem(const string& n, double p, int w)
        : Item(n, p), warrantyMonths(w) {
    }

    void display() const override {
        cout << "Name: " << getName()
            << " | Price: $" << fixed << setprecision(2) << getPrice()
            << " | Warranty: " << warrantyMonths << " months" << endl;
    }

    double getPrice() const override {
        return getBasePrice();
    }

    void receiptEntry() const override {
        cout << getName() << " - $" << fixed << setprecision(2) << getPrice() << endl;
    }
};

// Menu display
void showMenu() {
    cout << "\n************* Welcome to QuickMart POS *************\n"
        << "1 - Add item to store\n"
        << "2 - Display available items\n"
        << "3 - Buy item by name\n"
        << "4 - View receipt\n"
        << "0 - Exit\nChoice: ";
}

// Search function
int findItem(Item* store[], int count, const string& name) {
    for (int i = 0; i < count; ++i)
        if (store[i]->getName() == name)
            return i;
    return -1;
}

int main() {
    const int MAX_ITEMS = 50, MAX_PURCHASES = 20;
    Item* store[MAX_ITEMS];
    Item* purchases[MAX_PURCHASES];
    int storeCount = 0, purchaseCount = 0;
    int choice;

    do {
        showMenu();
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            if (storeCount >= MAX_ITEMS) {
                cout << "Store is full.\n";
                continue;
            }

            string type, name;
            double price;
            cout << "Enter item type (Food/Electronic): ";
            getline(cin, type);
            cout << "Enter item name: ";
            getline(cin, name);
            cout << "Enter price: ";
            cin >> price;
            cin.ignore();

            if (type == "Food" || type == "food") {
                string exp;
                cout << "Enter expiration date: ";
                getline(cin, exp);
                store[storeCount++] = new FoodItem(name, price, exp);
            }
            else if (type == "Electronic" || type == "electronic") {
                int warranty;
                cout << "Enter warranty in months: ";
                cin >> warranty;
                cin.ignore();
                store[storeCount++] = new ElectronicItem(name, price, warranty);
            }
            else {
                cout << "Invalid type.\n";
                continue;
            }
            cout << "Item added successfully!\n";

        }
        else if (choice == 2) {
            if (storeCount == 0)
                cout << "No items in store.\n";
            else
                for (int i = 0; i < storeCount; ++i)
                    store[i]->display();

        }
        else if (choice == 3) {
            if (purchaseCount >= MAX_PURCHASES) {
                cout << "Purchase limit reached.\n";
                continue;
            }

            string name;
            cout << "Enter item name: ";
            getline(cin, name);
            int idx = findItem(store, storeCount, name);
            if (idx != -1) {
                purchases[purchaseCount++] = store[idx];
                cout << "Purchased " << store[idx]->getName()
                    << " for $" << fixed << setprecision(2)
                    << store[idx]->getPrice() << endl;
            }
            else {
                cout << "Item not found.\n";
            }

        }
        else if (choice == 4) {
            cout << "---- Receipt ----\n";
            double total = 0;
            for (int i = 0; i < purchaseCount; ++i) {
                cout << i + 1 << ". ";
                purchases[i]->receiptEntry();
                total += purchases[i]->getPrice();
            }
            cout << "Total: $" << fixed << setprecision(2) << total << endl;

        }
        else if (choice != 0) {
            cout << "Invalid choice.\n";
        }

    } while (choice != 0);

    cout << "Thank you for shopping at QuickMart!\n";

    for (int i = 0; i < storeCount; ++i)
        delete store[i];

    return 0;
}
