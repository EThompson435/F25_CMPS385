#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

// ===============================
// Template Struct
// ===============================
template <typename T1, typename T2>
struct Appointment {
    T1 id;
    string name;
    string type;
    int timeUntil; // in hours
    T2 bill;
    string status; // "Pending" or "Completed"
};

// ===============================
// Function Declarations
// ===============================
template <typename T1, typename T2>
int loadAppointments(Appointment<T1, T2> appointments[]);

template <typename T1, typename T2>
void saveAppointments(Appointment<T1, T2> appointments[], int count);

template <typename T1, typename T2>
void addAppointment(Appointment<T1, T2> appointments[], int& count);

template <typename T1, typename T2>
void displayAppointments(Appointment<T1, T2> appointments[], int count);

template <typename T1, typename T2>
void markCompleted(Appointment<T1, T2> appointments[], int count);

template <typename T1, typename T2>
void appointmentSummary(Appointment<T1, T2> appointments[], int count);

// ===============================
// Load Appointments from File
// ===============================
template <typename T1, typename T2>
int loadAppointments(Appointment<T1, T2> appointments[]) {
    ifstream file("appointments.txt");
    if (!file.is_open()) return 0;

    int count = 0;
    string line;

    while (getline(file, line)) {
        if (line.empty()) continue;
        Appointment<T1, T2> appt;

        size_t pos = 0;
        string token;
        int field = 0;

        // Parse CSV manually
        while ((pos = line.find(',')) != string::npos) {
            token = line.substr(0, pos);
            line.erase(0, pos + 1);

            switch (field) {
            case 0: appt.id = token; break;
            case 1: appt.name = token; break;
            case 2: appt.type = token; break;
            case 3: appt.timeUntil = stoi(token); break;
            case 4: appt.bill = stof(token); break;
            }
            field++;
        }
        appt.status = line;
        appointments[count++] = appt;
    }

    file.close();
    return count;
}

// ===============================
// Save Appointments to File
// ===============================
template <typename T1, typename T2>
void saveAppointments(Appointment<T1, T2> appointments[], int count) {
    ofstream file("appointments.txt");
    for (int i = 0; i < count; ++i) {
        file << appointments[i].id << ","
            << appointments[i].name << ","
            << appointments[i].type << ","
            << appointments[i].timeUntil << ","
            << fixed << setprecision(2) << appointments[i].bill << ","
            << appointments[i].status << "\n";
    }
    file.close();
}

// ===============================
// Add New Appointment
// ===============================
template <typename T1, typename T2>
void addAppointment(Appointment<T1, T2> appointments[], int& count) {
    if (count >= 100) {
        cout << "Appointment list full!\n";
        return;
    }

    Appointment<T1, T2> appt;
    cout << "Enter appointment ID: ";
    cin >> appt.id;
    cin.ignore();

    cout << "Enter patient name: ";
    getline(cin, appt.name);

    cout << "Enter appointment type (General/Dental/Emergency/etc.): ";
    getline(cin, appt.type);

    cout << "Enter time until appointment (hours): ";
    cin >> appt.timeUntil;

    cout << "Enter estimated bill: ";
    cin >> appt.bill;

    appt.status = "Pending";

    appointments[count++] = appt;

    cout << "Appointment added!\n";
}

// ===============================
// Display All Appointments
// ===============================
template <typename T1, typename T2>
void displayAppointments(Appointment<T1, T2> appointments[], int count) {
    cout << "\n=========== APPOINTMENTS ===========\n";
    cout << left << setw(10) << "ID"
        << setw(20) << "Name"
        << setw(15) << "Type"
        << setw(8) << "Time"
        << setw(10) << "Bill"
        << setw(12) << "Status" << endl;
    cout << "---------------------------------------------------------------\n";

    for (int i = 0; i < count; ++i) {
        cout << left << setw(10) << appointments[i].id
            << setw(20) << appointments[i].name
            << setw(15) << appointments[i].type
            << setw(8) << appointments[i].timeUntil
            << "$" << setw(9) << fixed << setprecision(2) << appointments[i].bill
            << setw(12) << appointments[i].status << endl;
    }
}

// ===============================
// Mark Appointment as Completed
// ===============================
template <typename T1, typename T2>
void markCompleted(Appointment<T1, T2> appointments[], int count) {
    T1 searchID;
    cout << "Enter appointment ID to mark as completed: ";
    cin >> searchID;

    bool found = false;
    for (int i = 0; i < count; ++i) {
        if (appointments[i].id == searchID) {
            appointments[i].status = "Completed";
            cout << "Appointment " << searchID << " marked as Completed.\n";
            found = true;
            break;
        }
    }

    if (!found)
        cout << "Appointment not found.\n";
}

// ===============================
// Appointment Summary
// ===============================
template <typename T1, typename T2>
void appointmentSummary(Appointment<T1, T2> appointments[], int count) {
    int completed = 0;
    T2 totalEarnings = 0;

    for (int i = 0; i < count; ++i) {
        if (appointments[i].status == "Completed") {
            completed++;
            totalEarnings += appointments[i].bill;
        }
    }

    cout << "\n======== APPOINTMENT SUMMARY ========\n";
    cout << "Total Appointments: " << count << endl;
    cout << "Completed: " << completed << endl;
    cout << "Pending: " << (count - completed) << endl;
    cout << "Total Earnings: $" << fixed << setprecision(2) << totalEarnings << endl;
    cout << "=====================================\n";
}

// ===============================
// Main Function
// ===============================
int main() {
    Appointment<string, float> appointments[100];
    int count = loadAppointments(appointments);
    int choice;

    do {
        cout << "\n******* Welcome to Clinic Appointment Manager *******\n";
        cout << "1. Add New Appointment\n";
        cout << "2. Display All Appointments\n";
        cout << "3. Mark Appointment as Completed\n";
        cout << "4. View Appointment Summary\n";
        cout << "5. Exit\n ";
        cin >> choice;

        switch (choice) {
        case 1:
            addAppointment(appointments, count);
            break;
        case 2:
            displayAppointments(appointments, count);
            break;
        case 3:
            markCompleted(appointments, count);
            break;
        case 4:
            appointmentSummary(appointments, count);
            break;
        case 5:
            saveAppointments(appointments, count);
            cout << "Data saved to appointments.txt. Goodbye!\n";
            break;
        default:
            cout << "Invalid option. Try again.\n";
        }

    } while (choice != 5);

    return 0;
}
