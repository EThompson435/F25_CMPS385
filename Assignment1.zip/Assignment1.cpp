#include <iostream>
#include <iomanip>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;

struct Name {
    string first;
    string last;
};

struct Scores {
    double exam1; // 0�100
    double exam2; // 0�100
    double exam3; // 0�100
    double average; // computed as (e1 + e2 + e3)/3.0
    char letter; // A/B/C/D/F
};

struct Student {
    int id; // auto-generated
    Name name;
    string semester; // e.g., "Fall 2025"
    Scores scores; // defaults to zeros
};

Student gradebook[100];
int countStudents = 0;

// Generate a unique student ID
int generateID() {
    int id;
    bool unique;
    do {
        id = 10000 + rand() % 90000;
        unique = true;
        for (int i = 0; i < countStudents; i++) {
            if (gradebook[i].id == id) {
                unique = false;
                break;
            }
        }
    } while (!unique);
    return id;
}

// Compute average and letter grade
void computeGrade(Scores& s) {
    s.average = (s.exam1 + s.exam2 + s.exam3) / 3.0;
    if (s.average >= 90) s.letter = 'A';
    else if (s.average >= 80) s.letter = 'B';
    else if (s.average >= 70) s.letter = 'C';
    else if (s.average >= 60) s.letter = 'D';
    else s.letter = 'F';
}

// Find student by ID (return index or -1)
int findStudent(int id) {
    for (int i = 0; i < countStudents; i++) {
        if (gradebook[i].id == id) return i;
    }
    return -1;
}

// Menu option 1: Add new student
void addStudent() {
    if (countStudents >= 100) {
        cout << "Gradebook is full!\n";
        return;
    }
    Student s;
    cout << "First name: ";
    cin >> s.name.first;
    cout << "Last name: ";
    cin >> s.name.last;
    cout << "Semester (e.g., Fall 2025): ";
    cin.ignore();
    getline(cin, s.semester);

    s.id = generateID();
    s.scores = { 0, 0, 0, 0, 'F' };
    gradebook[countStudents++] = s;

    cout << "Great! " << s.name.first << " " << s.name.last << " has been added.\n";
    cout << "Assigned Student ID: " << s.id << endl;
    cout << "Press any key to return to Main Menu!\n";
    cin.get();
}

// Menu option 2: Enter/Update scores
void updateScores() {
    int id;
    cout << "Enter student ID: ";
    cin >> id;
    int idx = findStudent(id);
    if (idx == -1) {
        cout << "Student not found.\n";
        cout << "Press any key to return to Main Menu!\n";
        cin.ignore(); cin.get();
        return;
    }
    Student& s = gradebook[idx];
    cout << "Enter Exam 1 (0-100): ";
    cin >> s.scores.exam1;
    cout << "Enter Exam 2 (0-100): ";
    cin >> s.scores.exam2;
    cout << "Enter Exam 3 (0-100): ";
    cin >> s.scores.exam3;
    computeGrade(s.scores);
    cout << "Scores updated for " << s.name.first << " " << s.name.last
        << " (ID: " << s.id << ").\n";
    cout << fixed << setprecision(2);
    cout << "Average: " << s.scores.average << endl;
    cout << "Letter: " << s.scores.letter << endl;
    cout << "Press any key to return to Main Menu!\n";
    cin.ignore(); cin.get();
}

// Menu option 3: Report for one student
void reportStudent() {
    int id;
    cout << "Enter student ID: ";
    cin >> id;
    int idx = findStudent(id);
    if (idx == -1) {
        cout << "Student not found.\n";
        cout << "Press any key to return to Main Menu!\n";
        cin.ignore(); cin.get();
        return;
    }
    Student& s = gradebook[idx];
    cout << "------ Student Report ------\n";
    cout << "Name: " << s.name.last << ", " << s.name.first << endl;
    cout << "ID: " << s.id << endl;
    cout << "Semester: " << s.semester << endl;
    cout << "Exam 1: " << s.scores.exam1 << endl;
    cout << "Exam 2: " << s.scores.exam2 << endl;
    cout << "Exam 3: " << s.scores.exam3 << endl;
    cout << fixed << setprecision(2);
    cout << "Average: " << s.scores.average << endl;
    cout << "Letter: " << s.scores.letter << endl;
    cout << "----------------------------\n";
    cout << "Press any key to return to Main Menu!\n";
    cin.ignore(); cin.get();
}

// Menu option 4: Report for semester
void reportSemester() {
    string sem;
    cout << "Enter semester (e.g., Fall 2025): ";
    cin.ignore();
    getline(cin, sem);

    int found = 0;
    double total = 0, high = -1, low = 101;

    cout << "ID | Name | E1 E2 E3 | Avg | Letter\n";
    cout << "-------------------------------------------------------\n";
    for (int i = 0; i < countStudents; i++) {
        if (gradebook[i].semester == sem) {
            Student& s = gradebook[i];
            cout << s.id << " | "
                << s.name.last << ", " << s.name.first << " | "
                << s.scores.exam1 << " "
                << s.scores.exam2 << " "
                << s.scores.exam3 << " | "
                << fixed << setprecision(2) << s.scores.average << " | "
                << s.scores.letter << endl;
            found++;
            total += s.scores.average;
            if (s.scores.average > high) high = s.scores.average;
            if (s.scores.average < low) low = s.scores.average;
        }
    }

    if (found == 0) {
        cout << "No records for that semester.\n";
    }
    else {
        cout << "Students: " << found << endl;
        cout << "Semester Average: " << (total / found) << endl;
        cout << "Highest Average: " << high << endl;
        cout << "Lowest Average: " << low << endl;
    }
    cout << "Press any key to return to Main Menu!\n";
    cin.get();
}

// Menu option 5: List all students
void listStudents() {
    if (countStudents == 0) {
        cout << "No students added yet.\n";
    }
    else {
        cout << "ID | Name | Semester\n";
        cout << "-----------------------------------------\n";
        for (int i = 0; i < countStudents; i++) {
            cout << gradebook[i].id << " | "
                << gradebook[i].name.last << ", "
                << gradebook[i].name.first << " | "
                << gradebook[i].semester << endl;
        }
    }
    cout << "Press any key to return to Main Menu!\n";
    cin.ignore(); cin.get();
}

int main() {
    srand(time(0));
    int choice;
    do {
        cout << "\n*************** Faculty Gradebook ***************\n";
        cout << "Please choose one of the following operations\n";
        cout << "1- Add a new student record\n";
        cout << "2- Enter/Update scores (by ID)\n";
        cout << "3- Display report for a student (by ID)\n";
        cout << "4- Display report for a semester\n";
        cout << "5- List all students\n";
        cout << "6- Exit\n";
        cout << "Choice: ";
        cin >> choice;

        switch (choice) {
        case 1: addStudent(); break;
        case 2: updateScores(); break;
        case 3: reportStudent(); break;
        case 4: reportSemester(); break;
        case 5: listStudents(); break;
        case 6: cout << "Thank you for using the Faculty Gradebook!\nGoodbye!\n"; break;
        default: cout << "Invalid choice.\n"; break;
        }
    } while (choice != 6);

    return 0;
}

