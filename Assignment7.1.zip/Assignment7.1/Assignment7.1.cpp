#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

// Define a struct to represent an Order
struct Order {
    string id;
    string name;
    string item;
    int quantity;
    float price;
    string status; // "Pending" or "Served"
};

// Function declarations
void loadOrders(vector<Order>& orders);
void saveOrders(const vector<Order>& orders);
void placeOrder(vector<Order>& orders);
void displayOrders(const vector<Order>& orders);
void markServed(vector<Order>& orders);
void salesSummary(const vector<Order>& orders);

// Load orders from the file
void loadOrders(vector<Order>& orders) {
    ifstream inputFile("orders.txt");
    if (!inputFile) {
        cout << "Error opening file for reading.\n";
        return;
    }

    Order order;
    while (inputFile >> order.id >> order.name >> order.item >> order.quantity >> order.price >> order.status) {
        // Handle total calculation for orders
        float total = order.quantity * order.price;
        orders.push_back(order);
    }

    inputFile.close();
}

// Save orders to a file
void saveOrders(const vector<Order>& orders) {
    ofstream outputFile("orders.txt", ios::app);
    if (!outputFile) {
        cout << "Error opening file for writing.\n";
        return;
    }

    for (const auto& order : orders) {
        float total = order.quantity * order.price;
        outputFile << order.id << " "
            << order.name << " "
            << order.item << " "
            << order.quantity << " "
            << fixed << setprecision(2) << order.price << " "
            << fixed << setprecision(2) << total << " "
            << order.status << "\n";
    }

    outputFile.close();
}

// Place a new order
void placeOrder(vector<Order>& orders) {
    Order newOrder;
    cout << "Enter Order ID: ";
    cin >> newOrder.id;
    cin.ignore(); // to ignore any leftover newline character

    cout << "Enter customer name: ";
    getline(cin, newOrder.name);

    cout << "Enter menu item: ";
    getline(cin, newOrder.item);

    cout << "Enter quantity: ";
    cin >> newOrder.quantity;

    cout << "Enter price per item: ";
    cin >> newOrder.price;

    newOrder.status = "Pending";  // New order is always pending

    orders.push_back(newOrder);
    cout << "Order added!\n";
}

// Display all orders
void displayOrders(const vector<Order>& orders) {
    cout << "=========== CURRENT ORDERS ===========\n";
    cout << "ID\tName\tItem\tQty\tPrice\tTotal\tStatus\n";
    cout << "---------------------------------------------------\n";

    for (const auto& order : orders) {
        float total = order.quantity * order.price;
        cout << order.id << "\t"
            << order.name << "\t"
            << order.item << "\t"
            << order.quantity << "\t"
            << fixed << setprecision(2) << order.price << "\t"
            << fixed << setprecision(2) << total << "\t"
            << order.status << "\n";
    }
}

// Mark an order as served
void markServed(vector<Order>& orders) {
    string orderId;
    cout << "Enter Order ID to mark as served: ";
    cin >> orderId;

    for (auto& order : orders) {
        if (order.id == orderId && order.status == "Pending") {
            order.status = "Served";
            cout << "Order " << order.id << " marked as Served.\n";
            return;
        }
    }

    cout << "Order ID not found or already served.\n";
}

// View sales summary
void salesSummary(const vector<Order>& orders) {
    int totalOrders = orders.size();
    int servedCount = 0;
    float totalSales = 0.0;

    for (const auto& order : orders) {
        if (order.status == "Served") {
            servedCount++;
            totalSales += order.quantity * order.price;
        }
    }

    int pendingCount = totalOrders - servedCount;

    cout << "========== SALES SUMMARY ========== \n";
    cout << "Total Orders: " << totalOrders << "\n";
    cout << "Served: " << servedCount << "\n";
    cout << "Pending: " << pendingCount << "\n";
    cout << "Total Sales: $" << fixed << setprecision(2) << totalSales << "\n";
    cout << "===================================\n";
}

int main() {
    vector<Order> orders;
    loadOrders(orders);  // Load orders from the file at the beginning

    int choice;
    do {
        cout << "\n****** Welcome to Restaurant Order Manager ******\n";
        cout << "1. Place New Order\n2. Display All Orders\n3. Mark Order as Served\n4. View Sales Summary\n5. Exit\n ";
        cin >> choice;

        switch (choice) {
        case 1: placeOrder(orders); break;
        case 2: displayOrders(orders); break;
        case 3: markServed(orders); break;
        case 4: salesSummary(orders); break;
        case 5:
            saveOrders(orders);  // Save orders before exit
            cout << "Orders saved to orders.txt. Have a great day!\n";
            break;
        default:
            cout << "Invalid option. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}
