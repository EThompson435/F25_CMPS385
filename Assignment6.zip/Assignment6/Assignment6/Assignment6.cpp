#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

// =================== TEMPLATE STRUCT ===================
template <typename T1, typename T2>
struct Package {
    T1 id;
    string name;
    string type;
    int etaHours;
    T2 fee;
    string status; // "Pending" or "Delivered"
};

// =================== FUNCTION DECLARATIONS ===================
template <typename T1, typename T2>
int loadPackages(Package<T1, T2> packages[]);

template <typename T1, typename T2>
void savePackages(Package<T1, T2> packages[], int count);

template <typename T1, typename T2>
void addPackage(Package<T1, T2> packages[], int& count);

template <typename T1, typename T2>
void displayPackages(Package<T1, T2> packages[], int count);

template <typename T1, typename T2>
void markDelivered(Package<T1, T2> packages[], int count);

template <typename T1, typename T2>
void deliveryReport(Package<T1, T2> packages[], int count);

// =================== MAIN FUNCTION ===================
int main() {
    Package<int, double> packages[100];
    int count = loadPackages(packages);

    int choice;
    do {
        cout << "\n******** Welcome to Package Delivery Tracker ********\n";
        cout << "1. Add New Package\n";
        cout << "2. Display All Packages\n";
        cout << "3. Mark Package as Delivered\n";
        cout << "4. View Delivery Report\n";
        cout << "5. Exit\n ";
        cin >> choice;
        cin.ignore(); // clear newline

        switch (choice) {
        case 1:
            addPackage(packages, count);
            break;
        case 2:
            displayPackages(packages, count);
            break;
        case 3:
            markDelivered(packages, count);
            break;
        case 4:
            deliveryReport(packages, count);
            break;
        case 5:
            savePackages(packages, count);
            cout << "Data saved to packages.txt. Goodbye!" << endl;
            break;
        default:
            cout << "Invalid option. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}

// =================== LOAD PACKAGES ===================
template <typename T1, typename T2>
int loadPackages(Package<T1, T2> packages[]) {
    ifstream file("packages.txt");
    if (!file.is_open()) {
        return 0; // file not found
    }

    string header;
    getline(file, header); // skip header line

    int count = 0;
    while (!file.eof() && count < 100) {
        Package<T1, T2> pkg;
        char comma;
        file >> pkg.id >> comma;
        getline(file, pkg.name, ',');
        getline(file, pkg.type, ',');
        file >> pkg.etaHours >> comma >> pkg.fee >> comma;
        getline(file, pkg.status);

        if (file) packages[count++] = pkg;
    }

    file.close();
    return count;
}

// =================== SAVE PACKAGES ===================
template <typename T1, typename T2>
void savePackages(Package<T1, T2> packages[], int count) {
    ofstream file("packages.txt");
    file << "ID,Name,Type,ETA,Fee,Status\n";
    for (int i = 0; i < count; ++i) {
        file << packages[i].id << ","
            << packages[i].name << ","
            << packages[i].type << ","
            << packages[i].etaHours << ","
            << fixed << setprecision(2) << packages[i].fee << ","
            << packages[i].status << "\n";
    }
    file.close();
}

// =================== ADD PACKAGE ===================
template <typename T1, typename T2>
void addPackage(Package<T1, T2> packages[], int& count) {
    if (count >= 100) {
        cout << "Maximum package limit reached.\n";
        return;
    }

    Package<T1, T2> pkg;
    cout << "Enter package ID: ";
    cin >> pkg.id;
    cin.ignore();

    cout << "Enter recipient name: ";
    getline(cin, pkg.name);

    cout << "Enter delivery type (Standard/Express/Fragile): ";
    getline(cin, pkg.type);

    cout << "Enter delivery ETA (in hours): ";
    cin >> pkg.etaHours;

    cout << "Enter delivery fee: ";
    cin >> pkg.fee;

    pkg.status = "Pending";

    packages[count++] = pkg;

    cout << "Package added!\n";
}

// =================== DISPLAY PACKAGES ===================
template <typename T1, typename T2>
void displayPackages(Package<T1, T2> packages[], int count) {
    if (count == 0) {
        cout << "No packages available.\n";
        return;
    }

    cout << "\n============ PACKAGES ============\n";
    cout << left << setw(8) << "ID"
        << setw(12) << "Name"
        << setw(12) << "Type"
        << setw(8) << "ETA"
        << setw(10) << "Fee"
        << setw(12) << "Status" << "\n";
    cout << "-----------------------------------------------\n";

    for (int i = 0; i < count; ++i) {
        cout << left << setw(8) << packages[i].id
            << setw(12) << packages[i].name
            << setw(12) << packages[i].type
            << setw(8) << packages[i].etaHours
            << "$" << setw(9) << fixed << setprecision(2) << packages[i].fee
            << setw(12) << packages[i].status << "\n";
    }
}

// =================== MARK DELIVERED ===================
template <typename T1, typename T2>
void markDelivered(Package<T1, T2> packages[], int count) {
    if (count == 0) {
        cout << "No packages to update.\n";
        return;
    }

    T1 searchId;
    cout << "Enter package ID to mark as delivered: ";
    cin >> searchId;

    bool found = false;
    for (int i = 0; i < count; ++i) {
        if (packages[i].id == searchId) {
            packages[i].status = "Delivered";
            cout << "Package " << searchId << " marked as Delivered.\n";
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "Package ID not found.\n";
    }
}

// =================== DELIVERY REPORT ===================
template <typename T1, typename T2>
void deliveryReport(Package<T1, T2> packages[], int count) {
    int delivered = 0, pending = 0;
    double totalRevenue = 0;

    for (int i = 0; i < count; ++i) {
        if (packages[i].status == "Delivered") {
            delivered++;
            totalRevenue += packages[i].fee;
        }
        else {
            pending++;
        }
    }

    cout << "\n========== DELIVERY REPORT ==========\n";
    cout << "Total Packages: " << count << "\n";
    cout << "Delivered: " << delivered << "\n";
    cout << "Pending: " << pending << "\n";
    cout << "Total Revenue: $" << fixed << setprecision(2) << totalRevenue << "\n";
    cout << "=====================================\n";
}
