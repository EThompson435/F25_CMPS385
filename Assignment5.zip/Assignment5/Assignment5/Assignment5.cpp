﻿#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

const int MAX_ITEMS = 100;

struct Item {
    string name;
    string category;
    int quantity;
    double price;
};

struct Transaction {
    string type; // "BUY" or "RETURN"
    string itemName;
    int quantity;
    double unitPrice;
};

// Function Prototypes
int loadInventory(Item items[]);
void saveInventory(Item items[], int count);
void displayInventory(Item items[], int count);
void buyItem(Item items[], int count);
void returnItem(Item items[], int count);
void saveTransaction(Transaction t);
void showProfitReport();

void displayMenu() {
    cout << "\n******** Welcome to Store Inventory & Profit Tracker ********" << endl;
    cout << "Please choose one of the following operations:\n";
    cout << "1. Add New Item to Inventory\n";
    cout << "2. Display Inventory\n";
    cout << "3. Buy Item\n";
    cout << "4. Return Item\n";
    cout << "5. View Profit Report\n";
    cout << "6. Exit\n";
    cout << "-> ";
}

// Load inventory from inventory.txt
int loadInventory(Item items[]) {
    ifstream inFile("inventory.txt");
    int count = 0;
    if (inFile.is_open()) {
        string line;
        getline(inFile, line); // Skip header

        while (getline(inFile, line) && count < MAX_ITEMS) {
            size_t pos1 = line.find(',');
            size_t pos2 = line.find(',', pos1 + 1);
            size_t pos3 = line.find(',', pos2 + 1);

            items[count].name = line.substr(0, pos1);
            items[count].category = line.substr(pos1 + 1, pos2 - pos1 - 1);
            items[count].quantity = stoi(line.substr(pos2 + 1, pos3 - pos2 - 1));
            items[count].price = stod(line.substr(pos3 + 1));
            count++;
        }

        inFile.close();
    }
    return count;
}

// Save inventory to inventory.txt
void saveInventory(Item items[], int count) {
    ofstream outFile("inventory.txt");
    outFile << "Name,Category,Quantity,Price\n";
    for (int i = 0; i < count; i++) {
        outFile << items[i].name << "," << items[i].category << ","
            << items[i].quantity << "," << fixed << setprecision(2) << items[i].price << "\n";
    }
    outFile.close();
}

// Save a transaction to transactions.txt
void saveTransaction(Transaction t) {
    ofstream outFile("transactions.txt", ios::app);
    outFile << t.type << "," << t.itemName << "," << t.quantity << "," << fixed << setprecision(2) << t.unitPrice << "\n";
    outFile.close();
}

// Display current inventory
void displayInventory(Item items[], int count) {
    cout << "\n============== INVENTORY ==============\n";
    cout << left << setw(15) << "Item Name" << setw(15) << "Category"
        << setw(10) << "Qty" << setw(10) << "Price" << endl;
    cout << "---------------------------------------------\n";

    for (int i = 0; i < count; i++) {
        cout << left << setw(15) << items[i].name << setw(15) << items[i].category
            << setw(10) << items[i].quantity << "$" << fixed << setprecision(2) << items[i].price << endl;
    }
}

// Add a new item to inventory (in memory)
void addItem(Item items[], int& count) {
    if (count >= MAX_ITEMS) {
        cout << "Inventory full. Cannot add more items.\n";
        return;
    }

    cout << "Enter item name: ";
    cin.ignore();
    getline(cin, items[count].name);
    cout << "Enter category: ";
    getline(cin, items[count].category);
    cout << "Enter quantity: ";
    cin >> items[count].quantity;
    cout << "Enter price: ";
    cin >> items[count].price;

    cout << "Item added!\n";
    count++;
}

// Buy item
void buyItem(Item items[], int count) {
    string name;
    int qty;
    cout << "Enter item to buy: ";
    cin.ignore();
    getline(cin, name);
    cout << "Quantity: ";
    cin >> qty;

    for (int i = 0; i < count; i++) {
        if (items[i].name == name) {
            if (items[i].quantity >= qty) {
                items[i].quantity -= qty;

                Transaction t = { "BUY", items[i].name, qty, items[i].price };
                saveTransaction(t);

                double total = qty * items[i].price;
                cout << "Successfully purchased " << qty << " x " << name << " for $" << fixed << setprecision(2) << total << endl;
            }
            else {
                cout << "Not enough stock.\n";
            }
            return;
        }
    }
    cout << "Item not found.\n";
}

// Return item
void returnItem(Item items[], int count) {
    string name;
    int qty;
    cout << "Enter item to return: ";
    cin.ignore();
    getline(cin, name);
    cout << "Quantity: ";
    cin >> qty;

    for (int i = 0; i < count; i++) {
        if (items[i].name == name) {
            items[i].quantity += qty;

            Transaction t = { "RETURN", items[i].name, qty, items[i].price };
            saveTransaction(t);

            cout << qty << " x " << name << " returned and added back to inventory.\n";
            return;
        }
    }
    cout << "Item not found.\n";
}

// View profit report
void showProfitReport() {
    ifstream inFile("transactions.txt");
    string line;
    double revenue = 0, refunds = 0;

    while (getline(inFile, line)) {
        size_t pos1 = line.find(',');
        size_t pos2 = line.find(',', pos1 + 1);
        size_t pos3 = line.find(',', pos2 + 1);

        string type = line.substr(0, pos1);
        int qty = stoi(line.substr(pos2 + 1, pos3 - pos2 - 1));
        double price = stod(line.substr(pos3 + 1));
        double total = qty * price;

        if (type == "BUY") {
            revenue += total;
        }
        else if (type == "RETURN") {
            refunds += total;
        }
    }

    inFile.close();

    cout << "\n========== PROFIT REPORT ==========\n";
    cout << "Total Revenue: $" << fixed << setprecision(2) << revenue << endl;
    cout << "Total Refunds: $" << fixed << setprecision(2) << refunds << endl;
    cout << "Net Profit: $" << fixed << setprecision(2) << (revenue - refunds) << endl;
    cout << "==================================\n";
}

// Main Menu
int main() {
    Item items[MAX_ITEMS];
    int itemCount = loadInventory(items);
    int choice;

    do {
        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            addItem(items, itemCount);
            break;
        case 2:
            displayInventory(items, itemCount);
            break;
        case 3:
            buyItem(items, itemCount);
            break;
        case 4:
            returnItem(items, itemCount);
            break;
        case 5:
            showProfitReport();
            break;
        case 6:
            saveInventory(items, itemCount);
            cout << "Inventory and transactions saved. Goodbye!\n";
            break;
        default:
            cout << "Invalid option. Try again.\n";
        }

    } while (choice != 6);

    return 0;
}
