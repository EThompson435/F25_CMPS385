#include <iostream>
#include <string>
using namespace std;

struct TrafficLight {
    int id;
    string roadName;
    string color;
    TrafficLight* next;
};

TrafficLight* head = nullptr;
TrafficLight* current = nullptr;

// Function declarations
void addLight();
void displaySequence();
void advanceLight();
void resetSystem();

int main() {
    int choice;
    do {
        cout << "\n****** Welcome to Smart Traffic Light Controller ******\n";
        cout << "1. Add Road and Light\n";
        cout << "2. Display Light Sequence\n";
        cout << "3. Advance to Next Light\n";
        cout << "4. Reset System\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); // clear newline

        switch (choice) {
        case 1: addLight(); break;
        case 2: displaySequence(); break;
        case 3: advanceLight(); break;
        case 4: resetSystem(); break;
        case 5:
            cout << "Traffic system saved. Goodbye and drive safe!" << endl;
            break;
        default: cout << "Invalid option. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}

// Add a new traffic light
void addLight() {
    TrafficLight* newLight = new TrafficLight;
    cout << "Enter Road ID: ";
    cin >> newLight->id;
    cin.ignore();
    cout << "Enter Road Name: ";
    getline(cin, newLight->roadName);
    cout << "Enter Initial Light Color (Green/Yellow/Red): ";
    getline(cin, newLight->color);

    if (!head) {
        head = newLight;
        newLight->next = newLight; // circular
        current = head;
    }
    else {
        TrafficLight* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newLight;
        newLight->next = head;
    }

    cout << "Traffic light added for " << newLight->roadName << "." << endl;
}

// Display the traffic light sequence
void displaySequence() {
    if (!head) {
        cout << "No traffic lights in the system." << endl;
        return;
    }

    cout << "========== TRAFFIC LIGHT SEQUENCE ==========" << endl;
    cout << "ID Road Name Light" << endl;
    cout << "-------------------------------" << endl;

    TrafficLight* temp = head;
    do {
        cout << temp->id << " " << temp->roadName << " " << temp->color << endl;
        temp = temp->next;
    } while (temp != head);
}

// Advance to the next light
void advanceLight() {
    if (!current) {
        cout << "No traffic lights in the system." << endl;
        return;
    }

    // Set all lights to Yellow
    TrafficLight* temp = head;
    do {
        temp->color = "Yellow";
        temp = temp->next;
    } while (temp != head);

    // Current becomes Red
    current->color = "Red";
    // Next becomes Green
    current->next->color = "Green";

    cout << current->roadName << " -> " << current->color << endl;
    cout << current->next->roadName << " -> " << current->next->color << endl;

    // Move current pointer to next
    current = current->next;
}

// Reset the system
void resetSystem() {
    if (!head) {
        cout << "System already empty." << endl;
        return;
    }

    TrafficLight* temp = head;
    do {
        TrafficLight* nextNode = temp->next;
        delete temp;
        temp = nextNode;
    } while (temp != head);

    head = nullptr;
    current = nullptr;
    cout << "System reset. All traffic lights cleared." << endl;
}
