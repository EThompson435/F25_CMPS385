#include <iostream>
using namespace std;

// Maximum number of grades allowed
const int MAX_GRADES = 100;

// Function Declarations
void displayGrades(int grades[], int size, int index = 0);
int sumGrades(int grades[], int size, int index = 0);
int countFailing(int grades[], int size, int index = 0);
int findMax(int grades[], int size, int index = 0, int currentMax = -1);

int main() {
    int grades[MAX_GRADES];
    int gradeCount = 0;
    int choice;

    cout << "******** Welcome to Recursive Grade Analyzer ********\n";

    do {
        cout << "\nPlease choose one of the following operations:\n";
        cout << "1. Enter Grades\n";
        cout << "2. Display Grades\n";
        cout << "3. Calculate Average Grade\n";
        cout << "4. Count Failing Grades\n";
        cout << "5. Find Highest Grade\n";
        cout << "6. Exit\n";
        cout << "> ";
        cin >> choice;

        switch (choice) {
        case 1: {
            cout << "How many grades do you want to enter?\n> ";
            cin >> gradeCount;

            if (gradeCount > MAX_GRADES || gradeCount <= 0) {
                cout << "Invalid number of grades. Please enter between 1 and " << MAX_GRADES << ".\n";
                gradeCount = 0;
                break;
            }

            for (int i = 0; i < gradeCount; ++i) {
                cout << "Enter grade #" << (i + 1) << ": ";
                cin >> grades[i];
            }

            cout << "Grades successfully saved!\n";
            break;
        }

        case 2:
            if (gradeCount == 0) {
                cout << "No grades entered yet.\n";
            }
            else {
                cout << "Grades entered:\n";
                displayGrades(grades, gradeCount);
                cout << endl;
            }
            break;

        case 3:
            if (gradeCount == 0) {
                cout << "No grades to calculate average.\n";
            }
            else {
                double avg = static_cast<double>(sumGrades(grades, gradeCount)) / gradeCount;
                cout << "The average grade is: " << avg << endl;
            }
            break;

        case 4:
            if (gradeCount == 0) {
                cout << "No grades to analyze.\n";
            }
            else {
                int failing = countFailing(grades, gradeCount);
                cout << "Number of failing grades: " << failing << endl;
            }
            break;

        case 5:
            if (gradeCount == 0) {
                cout << "No grades to analyze.\n";
            }
            else {
                int maxGrade = findMax(grades, gradeCount);
                cout << "Highest grade: " << maxGrade << endl;
            }
            break;

        case 6:
            cout << "Thank you for using Recursive Grade Analyzer!\n";
            cout << "CMPS 385: Data Structures Fall 2025\n";
            break;

        default:
            cout << "Invalid option. Please try again.\n";
            break;
        }

    } while (choice != 6);

    return 0;
}

// Recursive function to display grades
void displayGrades(int grades[], int size, int index) {
    if (index >= size)
        return;
    cout << grades[index] << " ";
    displayGrades(grades, size, index + 1);
}

// Recursive function to sum grades
int sumGrades(int grades[], int size, int index) {
    if (index >= size)
        return 0;
    return grades[index] + sumGrades(grades, size, index + 1);
}

// Recursive function to count failing grades (< 60)
int countFailing(int grades[], int size, int index) {
    if (index >= size)
        return 0;
    int count = (grades[index] < 60) ? 1 : 0;
    return count + countFailing(grades, size, index + 1);
}

// Recursive function to find maximum grade
int findMax(int grades[], int size, int index, int currentMax) {
    if (index >= size)
        return currentMax;
    if (grades[index] > currentMax)
        currentMax = grades[index];
    return findMax(grades, size, index + 1, currentMax);
}
