#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

struct Patient {
    string id;
    string name;
    string condition;
    int severity;
    Patient* next;
};

Patient* head = nullptr;
int totalServed = 0;

// Function declarations
void loadPatients();
void savePatients();
void addPatient();
void displayQueue();
void servePatient();
void showSummary();
double calculateAverageSeverity();

int main() {
    loadPatients();

    int choice;
    do {
        cout << "\n****** Welcome to ER Patient Queue Manager ******\n";
        cout << "1. Add New Patient\n";
        cout << "2. Display Patient Queue\n";
        cout << "3. Serve Next Patient\n";
        cout << "4. View ER Summary\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(); // clear newline from input buffer

        switch (choice) {
        case 1: addPatient(); break;
        case 2: displayQueue(); break;
        case 3: servePatient(); break;
        case 4: showSummary(); break;
        case 5:
            savePatients();
            cout << "Patient queue saved to patients.txt. Stay safe!" << endl;
            break;
        default: cout << "Invalid option. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}

// Load patients from file
void loadPatients() {
    ifstream infile("patients.txt");
    if (!infile) return; // File not found, start with empty queue

    string id, name, condition, severityStr;
    while (getline(infile, id, ',') &&
        getline(infile, name, ',') &&
        getline(infile, condition, ',') &&
        getline(infile, severityStr))
    {
        Patient* newPatient = new Patient;
        newPatient->id = id;
        newPatient->name = name;
        newPatient->condition = condition;
        newPatient->severity = stoi(severityStr);
        newPatient->next = nullptr;

        if (!head) {
            head = newPatient;
        }
        else {
            Patient* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = newPatient;
        }
    }

    infile.close();
}

// Save patients to file
void savePatients() {
    ofstream outfile("patients.txt");
    Patient* temp = head;
    while (temp) {
        outfile << temp->id << "," << temp->name << "," << temp->condition << "," << temp->severity << "\n";
        temp = temp->next;
    }
    outfile.close();
}

// Add new patient
void addPatient() {
    Patient* newPatient = new Patient;
    cout << "Enter Patient ID: ";
    cin >> newPatient->id;
    cin.ignore(); // clear newline
    cout << "Enter patient name: ";
    getline(cin, newPatient->name);
    cout << "Enter condition: ";
    getline(cin, newPatient->condition);
    cout << "Enter severity (1-5): ";
    cin >> newPatient->severity;
    cin.ignore(); // clear newline

    newPatient->next = nullptr;

    if (!head) {
        head = newPatient;
    }
    else {
        Patient* temp = head;
        while (temp->next) temp = temp->next;
        temp->next = newPatient;
    }

    cout << "Patient added to the queue." << endl;
}

// Display patient queue
void displayQueue() {
    if (!head) {
        cout << "No patients in queue." << endl;
        return;
    }

    cout << "=========== CURRENT QUEUE ===========\n";
    cout << left << setw(10) << "ID" << setw(20) << "Name" << setw(20) << "Condition" << "Severity\n";
    cout << "-----------------------------------------\n";

    Patient* temp = head;
    while (temp) {
        cout << left << setw(10) << temp->id
            << setw(20) << temp->name
            << setw(20) << temp->condition
            << temp->severity << endl;
        temp = temp->next;
    }
}

// Serve next patient
void servePatient() {
    if (!head) {
        cout << "No patients in queue." << endl;
        return;
    }

    Patient* temp = head;
    cout << "Serving Patient: " << temp->id << " - " << temp->name << endl;
    head = head->next;
    delete temp;
    totalServed++;
}

// Calculate average severity
double calculateAverageSeverity() {
    if (!head) return 0.0;

    int sum = 0, count = 0;
    Patient* temp = head;
    while (temp) {
        sum += temp->severity;
        count++;
        temp = temp->next;
    }

    return (double)sum / count;
}

// Show ER summary
void showSummary() {
    int queueCount = 0;
    Patient* temp = head;
    while (temp) {
        queueCount++;
        temp = temp->next;
    }

    cout << "========== ER SUMMARY ==========\n";
    cout << "Total Patients Served: " << totalServed << endl;
    cout << "Patients in Queue: " << queueCount << endl;
    cout << fixed << setprecision(2);
    cout << "Average Severity of Waiting Patients: " << calculateAverageSeverity() << endl;
    cout << "================================\n";
}
